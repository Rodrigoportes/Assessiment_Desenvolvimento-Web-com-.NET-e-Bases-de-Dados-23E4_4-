﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EscolaADM.Migrations
{
    public partial class AdicionandoColunaImageFileName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
