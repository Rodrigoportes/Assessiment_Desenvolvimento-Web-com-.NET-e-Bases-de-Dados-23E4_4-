﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EscolaADM.Data.Models
{
    public class Aluno
    {

        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        public string NomeAluno { get; set; }

        [Required(ErrorMessage = "O campo Descrição é obrigatório.")]
        public string CursoAluno { get; set; }

        [Required(ErrorMessage = "O campo Descrição é obrigatório.")]
        public string DiciplinaAluno { get; set; }

        [Range(100000, 999999, ErrorMessage = "A Matrícula deve ter exatamente 6 dígitos.")]
        [Required(ErrorMessage = "O campo Matrícula é obrigatório.")]
        
        public int MatriculaAluno { get; set; }

        //public int ImageFile { get; set; }

        /*[NotMapped]
        public IFormFile Upload { get; set; }*/

    }
}
