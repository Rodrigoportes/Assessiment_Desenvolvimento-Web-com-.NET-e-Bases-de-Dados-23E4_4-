﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EscolaADM.Data.Models
{
    public class Disciplina
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        public string NomeDiciplina { get; set; }

        [Required(ErrorMessage = "O campo Descrição é obrigatório.")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "O campo Horas Semanais é obrigatório.")]
        [Range(1, 20, ErrorMessage = "As horas semanais devem estar entre 1 e 20.")]
        public int  TotalHorasSemanais { get; set; }

        
    }

}
